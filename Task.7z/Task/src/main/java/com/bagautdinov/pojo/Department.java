package com.bagautdinov.pojo;

import com.bagautdinov.AppManager;
import org.apache.log4j.Logger;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.HashSet;


/**
 * Класс-представление департамента со свойствами, аналогичными полям таблицы в базе;
 * Переопределяет методы {@link Department#hashCode()} и {@link Department#equals(Object)} для осуществления
 * работы с HashSet;
 * Поля {@link Department#depCode} и {@link Department#depJob} являются натуральным ключом таблицы
 * (сочетание значений уникально);
 * @author Roman Bagautdinov
 * @version 1.0
 */
@XmlRootElement(name = "department")
public class Department {
    /** Классовый логгер. При необходимости, можно специфицировать в файле log4j.properties (директория resources) */
    private static final Logger logger = Logger.getLogger(Department.class);

    /** Поле кода департамента */
    @XmlElement(name = "depCode")
    private String depCode;

    /** Поле работы департамента */
    @XmlElement(name = "depJob")
    private String depJob;

    /** Поле описания департамента */
    @XmlElement(name = "description")
    private String description;

    public Department(){}
    /**
     * Конструктор класса автоматически записывает созданные объекты в главный контейнер, объявленный в AppManager
     * @param depCode - код департамента
     * @param depJob - работа департамента
     * @param description - описание департамента
     * @see Department#Department(String, String, String)
     */
    public Department(String depCode, String depJob, String description) {
        this(depCode, depJob, description, AppManager.getInstance().getDepContainer().getDepartments());
    }

    /**
     * Расширенный конструктор, с кастомизируемым контейнером (HashSet) объектов
     * @param depCode - код департамента
     * @param depJob - работа департамента
     * @param description - описание департамента
     * @param departments - контейнер объектов
     * @see Department#Department(String, String, String, HashSet)
     */
    public Department(String depCode, String depJob, String description, HashSet<Department> departments) {
        this.depCode = depCode;
        this.depJob = depJob;
        this.description = description;

        if (departments.contains(this)) {
            logger.error("Trying to perform adding two or more entries with equals values of (depCode, depJob)");
            logger.error("Please, check entry data and restart program");
            System.exit(0);
        }
        departments.add(this);
        logger.info(String.format("Department object added to HashSet: %s", this.toString()));
    }

    /**
     * Стандартный геттер
     * @return возвращает поле {@link Department#depCode}
     */
    public String getDepCode() {
        return depCode;
    }

    /**
     * Стандартный геттер
     * @return возвращает поле {@link Department#depJob}
     */
    public String getDepJob() {
        return depJob;
    }

    /**
     * Стандартный геттер
     * @return возвращает поле {@link Department#description}
     */
    public String getDescription() {
        return description;
    }

    /**
     * Переопределение {@link Object#toString()}
     * @return строковое представление объекта
     */
    @Override
    public String toString() {
        return String.format("Department[depCode: \"%s\"; depJob: \"%s\"; description: \"%s\"]",
                this.depCode, this.depJob, this.description);
    }

    /**
     * Переопределение {@link Object#equals(Object)}
     * Сравнение основано на значениях полей {@link Department#depCode} и {@link Department#depJob}
     * Основано на натуральном ключе базы
     * @param obj - объект для сравнения
     * @return результат сравнения двух объектов {@link Department}
     */
    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        }
        Department department = (Department) obj;
        return department.depCode.equals(this.depCode) && department.depJob.equals(this.depJob);
    }

    /**
     * Переопределение {@link Object#hashCode()
     * Основано на натуральном ключе базы {@link Department#depCode} и {@link Department#depJob}
     * будут иметь одинаковое хэш-значение
     * Два объекта с одинаковыи значениями полей
     * @return хэш-код объекта
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((depCode == null) ? 0 : depCode.hashCode());
        result = prime * result + ((depJob == null) ? 0 : depJob.hashCode());
        return result;
    }
}

package com.bagautdinov.pojo.container;

import com.bagautdinov.pojo.Department;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.HashSet;


/**
 * Класс - контейнер объектов {@link Department}
 * Служит для реализации структуры XML представления
 * @author Roman Bagautdinov
 * @version 1.0
 */
@XmlRootElement(name="departments")
public class Departments {

    /**
     * Поле, хранящее набор уникальных (по сочетанию {@link Department#hashCode()} и {@link Department#equals(Object)})
     * объектов
     */
    @XmlElement(name="department")
    private  HashSet<Department> departments = new HashSet<Department>();

    /**
     * Стандартный геттер
     * @return возвращает поле {@link Departments#departments}
     */
    public  HashSet<Department> getDepartments() {
        return departments;
    }
}

package com.bagautdinov;

import com.bagautdinov.dump.Converter;
import com.bagautdinov.dump.Loader;
import com.bagautdinov.sync.Parser;
import com.bagautdinov.sync.Synchronizer;
import org.apache.log4j.Logger;


/**
 * Основной класс приложения. Отвечает за инициализацию {@link AppManager}, вызов требуемых методов,
 * и корректное завершение работы приложения
 * @author Roman Bagautdinov
 * @version 1.0
 */
public class Main {
    /** Классовый логгер. При необходимости, можно специфицировать в файле log4j.properties (директория resources) */
    private static final Logger logger = Logger.getLogger(Main.class);

    /**
     *
     * @param args - для корректной работы приложения необходимо передать 2 параметра
     *             1) Наименование требуемой операции (в формате строкового представления {@link Commands})
     *             2) Путь до файла, с которым будет осуществляться работа по выгрузке/синхронизации базы
     */
    public static void main(String[] args) {
        if (args.length < 2) {
            logger.error("Not enough arguments!");
            logger.error("Please, enter arguments in cli: [command_name] [(dump/sync)file_path]");
            System.exit(0);
        }
        AppManager manager = AppManager.getInstance();
        String command = args[0];
        String path = args[1];
        Commands selectedCommand = null;
        try {
            selectedCommand = Commands.valueOf(command);
        } catch (IllegalArgumentException argException) {
            logger.error("Command argument should be correct! (DUMP_DATA or SYNC_DATA)");
            manager.closeConnectionAndExit();
        }

        switch (selectedCommand) {
            case DUMP_DATA:
                Loader.loadDataFromDatabase();
                Converter.convertHashSetToXMLFile(path);
                break;

            case SYNC_DATA:
                Parser.parseXMLIntoHashSet(path);
                Synchronizer.updateDatabaseWinhContainerData();
                break;

            default:
                break;
        }

        manager.closeConnectionAndExit();
    }
}

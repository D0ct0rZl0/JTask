package com.bagautdinov;


/**
 * Перечисление, для удобной обработки параметров args
 * @author Roman Bagautdinov
 * @version 1.0
 */
public enum  Commands {
    /** Элемент, отвечающий за вызов методов дампа базы */
    DUMP_DATA,

    /** Элемент, отвечающий за вызов методов синхронизации базы */
    SYNC_DATA
}

package com.bagautdinov.dump;

import com.bagautdinov.AppManager;
import com.bagautdinov.pojo.Department;
import com.bagautdinov.pojo.container.Departments;
import org.apache.log4j.Logger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


/**
 * Класс, реализующий методы конвертации содержимого контейнера {@link Departments} в XML формат
 * @author Roman Bagautdinov
 * @version 1.0
 */
public class Loader {
    /** Классовый логгер. При необходимости, можно специфицировать в файле log4j.properties (директория resources) */
    private static final Logger logger = Logger.getLogger(Loader.class);
    private static String SQL_QUERY = "SELECT dep_code, dep_job, description FROM department;";

    /**
     * Метод, выгружающий данные из базы в контейнер {@link Departments}
     * Выгружает в основной контейнер {@link AppManager#getDepContainer()}
     */
    public static void loadDataFromDatabase() {
        logger.info("Loading data from database into AppManager container");
        try {
            Statement statement = AppManager.getInstance().getConnection().createStatement();
            ResultSet resultSet = statement.executeQuery(SQL_QUERY);
            while (resultSet.next()) {
                new Department(
                        resultSet.getString("dep_code"),
                        resultSet.getString("dep_job"),
                        resultSet.getString("description")
                );
            }
        } catch (SQLException sqlException) {
            logger.error("Cannot load data from database!", sqlException);
            AppManager.getInstance().closeConnectionAndExit();
        }
    }

    /**
     * Метод, выгружающий данные из базы в контейнер {@link Departments}
     * Выгружает в кастомный контейнер
     * @param customContainer - кастомный контейнер
     */
    public static void loadDataFromDatabase(Departments customContainer) {
        logger.info("Loading data from database into custom container");
        try {
            Statement statement = AppManager.getInstance().getConnection().createStatement();
            ResultSet resultSet = statement.executeQuery(SQL_QUERY);
            while (resultSet.next()) {
                new Department(
                        resultSet.getString("dep_code"),
                        resultSet.getString("dep_job"),
                        resultSet.getString("description"),
                        customContainer.getDepartments()
                );
            }
        } catch (SQLException sqlException) {
            logger.error("Cannot load data from database!", sqlException);
            AppManager.getInstance().closeConnectionAndExit();
        }
    }
}

package com.bagautdinov.dump;

import com.bagautdinov.AppManager;
import com.bagautdinov.pojo.container.Departments;
import org.apache.log4j.Logger;
import javax.xml.bind.*;
import java.io.File;


/**
 * Класс, реализующий методы конвертации содержимого контейнера {@link Departments} в XML формат
 * @author Roman Bagautdinov
 * @version 1.0
 */
public class Converter {
    /** Классовый логгер. При необходимости, можно специфицировать в файле log4j.properties (директория resources) */
    private static final Logger logger = Logger.getLogger(Converter.class);

    /**
     * Конвертирование основного контейнера {@link AppManager#getDepContainer()} в XML формат
     * @param path - путь к файлу для записи
     */
    public static void convertHashSetToXMLFile(String path) {
        Departments departments = AppManager.getInstance().getDepContainer();
        convertHashSetToXMLFile(path, departments);
    }

    /**
     * Конвертирование кастомного контейнера в XML формат
     * @param path - путь к файлу для записи
     * @param customContainer - контейнер с объектами для конвертации
     */
    public static void convertHashSetToXMLFile(String path, Departments customContainer) {
        logger.info("Conversion into XML started");
        try {
            logger.info("Performing data conversion into XML");
            JAXBContext jaxbContext = JAXBContext.newInstance(Departments.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            File file = new File(path);
            jaxbMarshaller.marshal(customContainer, file);
        } catch (JAXBException jaxbException) {
            logger.error("Converting data into XML was interrupted due to error: ", jaxbException);
            AppManager.getInstance().closeConnectionAndExit();
        }
        logger.info("Conversion successfully completed");
    }
}

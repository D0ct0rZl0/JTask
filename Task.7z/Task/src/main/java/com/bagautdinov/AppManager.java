package com.bagautdinov;

import com.bagautdinov.pojo.container.Departments;
import org.apache.log4j.Logger;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;


/**
 * Singleton, хранящий основные параметры приложения, и инициализирующий их
 * @author Roman Bagautdinov
 * @version 1.0
 */
public class AppManager {
    /** Классовый логгер. При необходимости, можно специфицировать в файле log4j.properties (директория resources) */
    private static final Logger logger = Logger.getLogger(AppManager.class);

    /** Путь до файла настроек базы */
    private static final String PATH_TO_DATABASE_PROPERTIES = "database.properties";

    /** Поле, хранящее инстанс класса (реализация паттерна "Одиночка") */
    private static AppManager instance = new AppManager();

    /** Поле, хранящее настройки после инициализации */
    private Properties properties;

    /** Поле, хранящее объект подключения к базе после инициализации */
    private Connection connection;

    /** Поле, хранящее контейнер объктов {@link com.bagautdinov.pojo.Department} после инициализации */
    private Departments depContainer;

    /**
     * Метод, осуществляющей получение настроек подключение и инициализирующий подключение к базе
     * @throws ClassNotFoundException - ошибка получения драйвера базы
     * @throws SQLException - ошибка осуществления подключения к базе
     */
    private void createConnection() throws ClassNotFoundException, SQLException{
        this.depContainer = new Departments();

        String driver = this.properties.getProperty("driver");
        String url = this.properties.getProperty("url");
        String username = this.properties.getProperty("username");
        String password = this.properties.getProperty("password");

        logger.info("Initializing driver class");
        Class.forName(driver);

        logger.info("Initializing connection");
        this.connection = DriverManager.getConnection(url, username, password);
    }

    /**
     * Приватный конструктор. Объект класса создается единожды при инициализации, и хранит в себе основные параметры
     * приложения
     * В конструкторе осуществляется вызов метода {@link AppManager#createConnection()} для инициализации настроек
     * и подключения к базе
     */
    private AppManager() {
        FileInputStream fileInputStream;
        this.properties = new Properties();

        logger.info(String.format("Trying to read database properties form %s", PATH_TO_DATABASE_PROPERTIES));
        try {
            fileInputStream = new FileInputStream(PATH_TO_DATABASE_PROPERTIES);
            this.properties.load(fileInputStream);
        } catch (IOException propertiesReadException) {
            logger.error("Database properties file is not founded!", propertiesReadException);
            System.exit(0);
        }
        logger.info(String.format("Properties form %s have been read", PATH_TO_DATABASE_PROPERTIES));

        logger.info("Establishing database connection");
        try {
            createConnection();
        } catch (ClassNotFoundException classNotFoundException) {
            logger.error("Failure on finding database driver class!", classNotFoundException);
            System.exit(0);
        } catch (SQLException sqlException) {
            logger.error("Failure on performing connection to database!", sqlException);
            System.exit(0);
        }
        logger.info("Connection established successfully");
    }

    /**
     * Метод получения инстанса класса. Обеспечивает уникальность объекта менеджера для всего приложения
     * @return объект {@link AppManager#instance}
     */
    public static synchronized AppManager getInstance() {
        return instance;
    }

    /**
     * Стандартный геттер
     * @return возвращает поле {@link AppManager#properties}
     */
    public Properties getProperties() {
        return this.properties;
    }

    /**
     * Стандартный геттер
     * @return возвращает поле {@link AppManager#connection}
     */
    public Connection getConnection() {
        return this.connection;
    }

    /**
     * Стандартный геттер
     * @return возвращает поле {@link AppManager#depContainer}
     */
    public Departments getDepContainer() {
        return depContainer;
    }

    /**
     * Метод осуществляет закрытие подключения к базе и выход из приложения
     * Рекомендуется вызывать при возникновении ошибок, не совместимых с дальнейшим корректным выполнением программы
     * Обязателен вызов при завершении работы приложения
     */
    public void closeConnectionAndExit() {
        logger.info("Closing connection");
        try {
            this.connection.close();
        } catch (SQLException sqlException) {
            logger.error("Failure on closing connection!", sqlException);
            logger.warn("Check your database connection pool");
            System.exit(0);
        }
        logger.info("Connection closed successfully");
        System.exit(0);
    }
}

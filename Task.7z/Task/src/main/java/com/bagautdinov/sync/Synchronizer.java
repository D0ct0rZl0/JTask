package com.bagautdinov.sync;

import com.bagautdinov.AppManager;
import com.bagautdinov.dump.Loader;
import com.bagautdinov.pojo.Department;
import com.bagautdinov.pojo.container.Departments;
import org.apache.log4j.Logger;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;


/**
 * Класс, отвечающий за синхронизацию содержимого {@link AppManager#getDepContainer()} с базой данных
 * @author Roman Bagautdinov
 * @version 1.0
 */
public class Synchronizer {
    /** Классовый логгер. При необходимости, можно специфицировать в файле log4j.properties (директория resources) */
    private static final Logger logger = Logger.getLogger(Synchronizer.class);

    /** Поле, содержащее SQL запрос к базе (UPDATE)*/
    private static final String SQL_UPDATE = "UPDATE department SET description=? WHERE dep_code=? AND dep_job=?;";

    /** Поле, содержащее SQL запрос к базе (INSERT)*/
    private static final String SQL_INSERT = "INSERT INTO department(dep_code, dep_job, description) VALUES (?, ?, ?);";

    /** Поле, содержащее SQL запрос к базе (DELETE)*/
    private static final String SQL_DELETE = "DELETE FROM department WHERE dep_code=? AND dep_job=?;";

    /**
     * Метод, осуществляющий синхронизацию содержимого {@link AppManager#getDepContainer()} с базой данных
     * Все запросы осуществляются в единой транзакции
     */
    public static void updateDatabaseWinhContainerData() {
        Departments tempContainer = new Departments();
        Departments mainContainer = AppManager.getInstance().getDepContainer();
        Loader.loadDataFromDatabase(tempContainer);

        try {
            Statement statement = AppManager.getInstance().getConnection().createStatement();
            PreparedStatement updateStatement = AppManager.getInstance().getConnection().prepareStatement(SQL_UPDATE);
            PreparedStatement insertStatement = AppManager.getInstance().getConnection().prepareStatement(SQL_INSERT);
            PreparedStatement deleteStatement = AppManager.getInstance().getConnection().prepareStatement(SQL_DELETE);

            logger.info("Transaction started");
            statement.execute("BEGIN;");

            for (Department department:
                 mainContainer.getDepartments()) {
                if (tempContainer.getDepartments().contains(department)) {
                    tempContainer.getDepartments().remove(department);

                    updateStatement.setString(1, department.getDescription());
                    updateStatement.setString(2, department.getDepCode());
                    updateStatement.setString(3, department.getDepJob());
                    updateStatement.execute();
                    logger.info(String.format("Updating %s completed", department));
                } else {
                    insertStatement.setString(1, department.getDepCode());
                    insertStatement.setString(2, department.getDepJob());
                    insertStatement.setString(3, department.getDescription());
                    insertStatement.execute();
                    logger.info(String.format("Inserting %s completed", department));
                }
            }

            for (Department oldEntry:
                 tempContainer.getDepartments()) {
                deleteStatement.setString(1, oldEntry.getDepCode());
                deleteStatement.setString(2, oldEntry.getDepJob());
                deleteStatement.execute();
                logger.info(String.format("Deleting %s completed", oldEntry));
            }

            statement.execute("COMMIT;");
            logger.info("Transaction executed");
        } catch (SQLException sqlException) {
            logger.info("Transaction cancelled");
            logger.error("Database synchronization stopped due to raised error!", sqlException);
            AppManager.getInstance().closeConnectionAndExit();
        }
    }
}

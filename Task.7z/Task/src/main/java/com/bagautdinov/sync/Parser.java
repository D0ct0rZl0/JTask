package com.bagautdinov.sync;

import com.bagautdinov.AppManager;
import com.bagautdinov.pojo.Department;
import org.apache.log4j.Logger;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;
import org.xml.sax.SAXException;


/**
 * Класс, отвечающий за парсинг XML файлов в объекты {@link Department}
 * Использует технологию XML DOM
 * @author Roman Bagautdinov
 * @version 1.0
 */
public class Parser {
    /** Классовый логгер. При необходимости, можно специфицировать в файле log4j.properties (директория resources) */
    private static final Logger logger = Logger.getLogger(Parser.class);

    /**
     * Метод создает объект класса {@link Document} из содержимого переданного по пути файла, для последующей обработки
     * Является внутренним вспомогательным методом класса
     * @param path - путь до файла с XML репрезентацией базы данных
     * @return объект класса {@link Document} для последующей обработки
     */
    private static Document getDOM (String path) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = null;

        try {
            builder = factory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }

        Document doc = null;
        try {
            doc = builder.parse(new File(path));
            doc.getDocumentElement().normalize();
        } catch (SAXException e) {
            e.printStackTrace();
            AppManager.getInstance().closeConnectionAndExit();
        } catch (IOException ioException) {
            logger.error("IO exception (check file path):", ioException);
            AppManager.getInstance().closeConnectionAndExit();
        }

        return doc;
    }

    /**
     * Метод осуществляет создание объектов из элементов XML документа
     * @param path - путь до файла с XML репрезентацией базы данных
     */
    public static void parseXMLIntoHashSet (String path) {
        Document doc = getDOM(path);
        NodeList departmentNodes = doc.getElementsByTagName("department");

        logger.info("XML conversion started");
        for (int depNum = 0; depNum < departmentNodes.getLength(); depNum++) {
            Node depNode = departmentNodes.item(depNum);

            if (depNode.getNodeType() == Node.ELEMENT_NODE) {
                Element departmentElem = (Element) depNode;
                new Department(
                        departmentElem.getElementsByTagName("depCode").item(0).getTextContent(),
                        departmentElem.getElementsByTagName("depJob").item(0).getTextContent(),
                        departmentElem.getElementsByTagName("description").item(0).getTextContent()
                );
            }
        }
        logger.info("All department objects has been read from XML file");
    }
}
